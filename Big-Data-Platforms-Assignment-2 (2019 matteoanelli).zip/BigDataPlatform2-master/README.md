# BigDataPlatform2 - Working on data ingestion features

---------------------------------------------------------------------------

This assignment is part of a collection of 3 assignment of the Big Data Platform course at Aalto University.
* [Assignment 1](https://github.com/matteoanelli/BigDataPlatform) : Design of a big data platform (Main components). [Report](https://github.com/matteoanelli/BigDataPlatform/blob/master/assignment-1-801979-master/reports/Report.md)
* [Assignment 2](https://github.com/matteoanelli/BigDataPlatform2) : Data Ingestion [Report](https://github.com/matteoanelli/BigDataPlatform2/blob/master/assignment-2-801979/reports/Report.md)
* [Assignment 3](https://github.com/matteoanelli/BigDataPlatform3) : Analytics [Report](https://github.com/matteoanelli/BigDataPlatform3/blob/master/assignment-3/reports/Report.md)


The [Report](https://github.com/matteoanelli/BigDataPlatform2/blob/master/assignment-2-801979/reports/Report.md) is a full explanation of the project.

---------------------------------------------------------------------------
